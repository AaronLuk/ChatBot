import os
import shutil
import pathlib

joinpath = os.path.join

def clean_dir(path):
    try:
        shutil.rmtree(path)
    except Exception as e:
        pass # Expected
    pathlib.Path(path).mkdir(parents=True, exist_ok=True)

def compile_py(src_root, dst_root):
    for root, directories, filenames in os.walk(src_root):
        for filename in filenames:
            if not filename.lower().endswith(".py") and not filename.lower().endswith(".ini"):
                continue
            relative_dir = root[len(src_root) + 1:]
            dst_dir = joinpath(dst_root, relative_dir)
            pathlib.Path(dst_dir).mkdir(parents=True, exist_ok=True)
            src = joinpath(root, filename)
            if root == src_root and filename == "main.py":
                os.system("echo copying  : " + joinpath(relative_dir, filename) + os.linesep)
                os.system("cp " + src + " " + dst_dir + os.linesep)
            elif filename == "__init__.py" or filename.lower().endswith(".ini"):
                os.system("echo copying  : " + joinpath(relative_dir, filename) + os.linesep)
                os.system("cp " + src + " " + dst_dir + os.linesep)
            else:
                cmd = "nuitka --module --remove-output --no-pyi-file --output-dir=" + dst_dir + " " + src
                os.system("echo compiling: " + joinpath(relative_dir, filename) + os.linesep)
                os.system(cmd + os.linesep)

# start exec
src_root = "C:/Users/wttwhchen/Desktop/nuitka/DD_engine"
dst_root = "C:/Users/wttwhchen/Desktop/nuitka/DD_output"

clean_dir(dst_root)
compile_py(src_root, dst_root)

