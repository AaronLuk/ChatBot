#coding=UTF-8

####################################################################################
## 1. 在每一個folder加上”__init__.py”，cython可以幫build出整個檔案結構
## 2. 切記每一個py檔都不能有語法錯誤，否則會build error
## 3. 切記禁止circular import的使用，否則會出現 ImportError: cannot import name XXXX
##    [錯誤示範]
##    A.py
##    import B
##    B.py
##    import A
## 4. 執行程式
##    > cd ../<target app folder>
##    > python setup_by_cython.py build
####################################################################################

import os
import shutil
import pathlib

from distutils.core import setup
from Cython.Build import cythonize

joinpath = os.path.join

def compile_py(src_root, dst_root):
    for root, directories, filenames in os.walk(src_root):
        for filename in filenames:
            if not filename.lower().endswith(".py") and not filename.lower().endswith(".ini"):
                continue
            relative_dir = root[len(src_root) + 1:]
            dst_dir = joinpath(dst_root, relative_dir)
            pathlib.Path(dst_dir).mkdir(parents=True, exist_ok=True)
            src = joinpath(root, filename)

            print("src : ", src)
            print("dst_dir : ", dst_dir)

            if root == src_root and filename == "main.py":
                os.system("echo copying  : " + joinpath(relative_dir, filename) + os.linesep)
                #os.system("cp " + src + " " + dst_dir + os.linesep)
                shutil.copy2(src, dst_dir)
            elif filename == "__init__.py" or filename.lower().endswith(".ini"):
                os.system("echo copying  : " + joinpath(relative_dir, filename) + os.linesep)
                #os.system("cp " + src + " " + dst_dir + os.linesep)
                shutil.copy2(src, dst_dir)
            else:
                setup(
                    name = os.path.splitext(src)[0],
                    ext_modules = cythonize(src),
                )

# start exec
project_name = "src"
is_win_os = True

src_root = project_name
if is_win_os:
    dst_root = "build/lib.win-amd64-3.6/" + project_name
else:
    dst_root = "build/lib.linux-x86_64-3.6/" + project_name
compile_py(src_root, dst_root)
