import neo4j
from neo4j import GraphDatabase
import spacy

entity_tokenizer = spacy.load(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\TOKENIZER_NER_ATTR_MACHINE_DATE_TIME_DESC_DIR_MEASUREMENT_QUANTITY')

class Token:
    def __init__(self, word, entity_label_):
        self.word = word
        self.label_ = entity_label_
    
    def info(self):
        return self.word + " | " + self.label_
class Parsed_Entity_Lists:
    def __init__(self, valid, invalid):
        self.valid = valid
        self.invalid = invalid
class QueryObject:
    # query - original sentence
    # tokens - list of tokens
    # intent - intent
    # invalid = list of invalid tokens
    def __init__(self, intent, query, tokens, invalid = []):
        self.query = query # string
        self.tokens = tokens # list
        self.intent = intent
        self.invalid_entities = invalid
class Sorted_Entity_Lists:
    def __init__(self, MACHINE_list, EMPLOYEE_list, TOOL_list, ATTR_list, DATE_list, TIME_list, LOT_list, DESC_list, DIRECTION_list, MEASUREMENT_list, QUANTITY_list):
        self.MACHINE_list = MACHINE_list
        self.EMPLOYEE_list = EMPLOYEE_list
        self.TOOL_list = TOOL_list
        self.ATTR_list = ATTR_list
        self.DATE_list = DATE_list
        self.TIME_list = TIME_list
        self.LOT_list = LOT_list
        self.DESC_list = DESC_list
        self.DIRECTION_list = DIRECTION_list
        self.MEASUREMENT_list = MEASUREMENT_list
        self.QUANTITY_list = QUANTITY_list
# sort the entities into lists
def sort_entities(tokens):
    MACHINE_list = []
    EMPLOYEE_list = []
    TOOL_list = []
    ATTR_list = []
    DATE_list = []
    TIME_list = []
    LOT_list = []
    DESC_list = []
    DIRECTION_list = []
    MEASUREMENT_list = []
    QUANTITY_list = []

    for ent in tokens:
        if ent.label_ != '':
            if ent.label_ == '<MACHINE>':
                MACHINE_list.append(ent)
            elif ent.label_ == '<ATTR>':
                ATTR_list.append(ent)
            elif ent.label_ == '<LOT>':
                LOT_list.append(ent)
            elif ent.label_ == '<TOOL>':
                TOOL_list.append(ent)
            elif ent.label_ == '<EMPLOYEE>':
                EMPLOYEE_list.append(ent)
            elif ent.label_ == '<DATE>':
                DATE_list.append(ent)
            elif ent.label_ == '<TIME>':
                TIME_list.append(ent)
            elif ent.label_ == '<DESC>':
                DESC_list.append(ent)
            elif ent.label_ == '<DIRECTION>':
                DIRECTION_list.append(ent)
            elif ent.label_ == '<MEASUREMENT>':
                MEASUREMENT_list.append(ent)
            elif ent.label_ == '<QUANTITY>':
                QUANTITY_list.append(ent)

    return Sorted_Entity_Lists(MACHINE_list, EMPLOYEE_list,TOOL_list, ATTR_list, DATE_list, TIME_list, LOT_list, DESC_list, DIRECTION_list, MEASUREMENT_list, QUANTITY_list)

# returns a list of Token objects. 
# Each token object is a word and the corresponding entity type
# Entities are padded entities - <OBJ>, <DIR>, <DESC>, <ATTR>, <TEMPORAL>
def tokenize(query, tokenizer):
    doc = tokenizer(query)
    res = []

    entity_positions = [(e.start, e.end) for e in doc.ents] # positions of each entitiy
    d = 0
    while d < len(doc):
        if(len(entity_positions) != 0):
            start = entity_positions[0][0]
            end = entity_positions[0][1]
    
        if(doc[d].ent_type_ == ''): # if token has no entity
            res.append(Token(doc[d].text, doc[d].ent_type_))
            d = d+1
        else: # if token has entity
            word = ''
            e = start
            while e < end:
                word+= doc[e].text + ' '
                # d+=1
                e+=1 
            res.append(Token(word.strip(), doc[d].ent_type_))
            d = e
            del entity_positions[0]

    return res
# Get attribute dictionary
def get_attribute_dictionary(driver):
    query_string = 'MATCH (A:Attribute) RETURN A.name, A.abbrev'
    attributes = [dict(_) for _ in driver.query(query_string)] # a list of dictionaries. key: attribute_name, value: attribute_abbreviation

    if len(attributes) > 0: # if can find attributes
        list_of_keys = list(attributes[0].keys())
        attribute_name = list_of_keys[0]
        attribute_abbrev = list_of_keys[1]
        attribute_dict = {}
        for a in attributes:
            attribute_dict[a[attribute_name]] = a[attribute_abbrev]

        return attribute_dict

    else: # if no attributes found return empty dict
        return {} 
# Get machine names
def get_machines(driver):
    query_string = 'MATCH (E:Equipment) RETURN E.equipmentModel'
    machine_names = []
    list_of_machines = driver.query(query_string)
    if len(list_of_machines) > 0:
        for m in list_of_machines:
            machine_names.append(m.value())
        return machine_names
    
    else:
        return []

def validate_attributes(extracted_attributes, driver):
    tokens = []
    invalid_list = []    

    # query database for all the types attributes
    attribute_dict = get_attribute_dictionary(driver)

    # check if attribute given in query exists
    for attr in extracted_attributes:
        is_valid = False
        for a in attribute_dict:
            attr_full = a
            attr_abbrev = attribute_dict[a]

            if attr.word.lower() == attr_abbrev.lower() or attr.word.lower() == attr_full.lower():
                tokens.append(Token(attr_abbrev, "<ATTR>"))
                is_valid = True
                break
        if not is_valid:
            invalid_list.append(Token(attr.word, '<ATTR>'))
        
    return Parsed_Entity_Lists(tokens, invalid_list)

def validate_machine(extracted_machines, driver):
    tokens = []
    invalid_list = []
    machine_names = get_machines(driver)
    
    for m in extracted_machines:
        is_valid = False
        for mach in machine_names:
            if m.word.lower() == mach.lower():
                tokens.append(Token(mach, '<MACHINE>'))
                is_valid = True
                break
        if not is_valid:
            invalid_list.append(Token(m.word, '<MACHINE>'))

    return Parsed_Entity_Lists(tokens, invalid_list)

def validate_desc(list_of_desc):
    desc = list_of_desc[0].word.lower()
    list_of_more = ['great', 'high', 'long', 'more', 'most', 'best']
    list_of_less = ['low', 'less', 'few', 'fall', 'least', 'worst']

    for m in list_of_more:
        if m in desc:
            return Token('>', '<DESC>')
    for l in list_of_less:
        if l in desc:
            return Token('<', '<DESC>')

def validate_quantity(list_of_quantity):
    return Token(list_of_quantity[0], '<QUANTITY>')

def validate_measurement(list_of_measurement):
    return Token(list_of_measurement[0], '<MEASUREMENT>')

def validate_stats(driver, queryObj):

    # get specific tokens
    # list of specific_tokens
    specific_tokens = tokenize(queryObj.query, entity_tokenizer)

    # returns a sorted entity list
    # entities are sorted into their list
    sorted_entities = sort_entities(specific_tokens)

    # check validity of machine and attributes
    machine_entities = validate_machine(sorted_entities.MACHINE_list, driver)
    attribute_entities = validate_attributes(sorted_entities.ATTR_list, driver)

    # lists to contain all the tokens to create a new QueryObject
    valid_tokens = []
    invalid_tokens = []

    # add validated machine and attributes to the final lists
    valid_tokens.extend(machine_entities.valid)
    valid_tokens.extend(attribute_entities.valid)

    invalid_tokens.extend(machine_entities.invalid)
    invalid_tokens.extend(attribute_entities.invalid)

    # add the remaining entities
    for date in sorted_entities.DATE_list:
        valid_tokens.append(date)
    for time in sorted_entities.TIME_list:
        valid_tokens.append(time)
    for direction in sorted_entities.DIRECTION_list:
        valid_tokens.append(direction)
    for desc in sorted_entities.DESC_list:
        valid_tokens.append(desc)
    for measurement in sorted_entities.MEASUREMENT_list:
        valid_tokens.append(measurement)
    for quantity in sorted_entities.QUANTITY_list:
        valid_tokens.append(quantity)

    return QueryObject(queryObj.intent, queryObj.query, valid_tokens, invalid_tokens)

def validate_select(driver, queryObj):

    specific_tokens = tokenize(queryObj.query, entity_tokenizer)

    sorted_entities = sort_entities(specific_tokens)
    
    machine_entities = validate_machine(sorted_entities.MACHINE_list, driver)
    attribute_entities = validate_attributes(sorted_entities.ATTR_list, driver)
    desc_entities = validate_desc(sorted_entities.DESC_list)

    valid_tokens = []
    invalid_tokens = []

    valid_tokens.extend(machine_entities.valid)
    valid_tokens.extend(attribute_entities.valid)
    valid_tokens.append(desc_entities)

    invalid_tokens.extend(machine_entities.invalid)
    invalid_tokens.extend(attribute_entities.invalid)

    for date in sorted_entities.DATE_list:
        valid_tokens.append(date)
    for time in sorted_entities.TIME_list:
        valid_tokens.append(time)
    for direction in sorted_entities.DIRECTION_list:
        valid_tokens.append(direction)
    for measurement in sorted_entities.MEASUREMENT_list:
        valid_tokens.append(measurement)
    for quantity in sorted_entities.QUANTITY_list:
        valid_tokens.append(quantity)

    return QueryObject(queryObj.intent, queryObj.query, valid_tokens, invalid_tokens)

def validate_basic_info(driver, queryObj):
    
    # get specific tokens
    # list of specific_tokens
    specific_tokens = tokenize(queryObj.query, entity_tokenizer)

    # returns a sorted entity list
    # entities are sorted into their list
    sorted_entities = sort_entities(specific_tokens)

    # check validity of machine and attributes
    machine_entities = validate_machine(sorted_entities.MACHINE_list, driver)
    attribute_entities = validate_attributes(sorted_entities.ATTR_list, driver)

    # lists to contain all the tokens to create a new QueryObject
    valid_tokens = []
    invalid_tokens = []

    # add validated machine and attributes to the final lists
    valid_tokens.extend(machine_entities.valid)
    valid_tokens.extend(attribute_entities.valid)

    invalid_tokens.extend(machine_entities.invalid)
    invalid_tokens.extend(attribute_entities.invalid)

    # add the rest of the entities
    for date in sorted_entities.DATE_list:
        valid_tokens.append(date)
    for time in sorted_entities.TIME_list:
        valid_tokens.append(time)
    for direction in sorted_entities.DIRECTION_list:
        valid_tokens.append(direction)
    for desc in sorted_entities.DESC_list:
        valid_tokens.append(desc)
    for measurement in sorted_entities.MEASUREMENT_list:
        valid_tokens.append(measurement)
    for quantity in sorted_entities.QUANTITY_list:
        valid_tokens.append(quantity)

    return QueryObject(queryObj.intent, queryObj.query, valid_tokens, invalid_tokens)

def validate(driver, queryObj):

    intent = queryObj.intent

    if intent == 'Stats':
        return validate_stats(driver, queryObj)
    elif intent == 'General Selection':
        return validate_select(driver, queryObj)
    elif intent == 'Specific Selection':
        return validate_select(driver, queryObj)
    elif intent == 'Basic Information':
        return validate_basic_info(driver, queryObj)



# replace original tokens with specific entities
    # <OBJ> - <MACHINEID>, <PRODUCT>, <EMPLOYEE>, <INVENTORY>, <RECEIPE>
    # <ATTR> - <ATTR>
    # <TEMPORAL> - <DATE>, <TIME>
    # <MEASUREMENT> - 
    # <DESC> - 
