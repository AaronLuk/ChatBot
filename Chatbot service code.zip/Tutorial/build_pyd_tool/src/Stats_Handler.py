import neo4j
from neo4j import GraphDatabase
import enchant
import pandas as pd

class ResultsObject:

    def __init__(self, type, result):
        self.type = type
        self.result = result

def is_date(temporal):
    date_words = ['jan', 'january', 'feb', 'feburary', 'mar', 'march', 'apr', 'april',
    'may', 'jun', 'june', 'jul', 'july', 'aug', 'august', 'sep', 'september', 'oct', 'october',
    'nov', 'november', 'dec', 'december', 'day', 'days', 'mon', 'monday', 'tues', 'tuesday', 'wed',
    'wednesday', 'thurs', 'thursday', 'fri', 'friday', 'sat', 'saturday', 'sun', 'sunday', 'week',
    'day', 'month', 'year']

    for d in date_words:
        if temporal.contains(d):
            return True
    
    return False

def is_time(temporal):
    time_words = ['hr', 'hour', 'min', 'minute']

    for t in time_words:
        if temporal.contains(t):
            return True
    
    return False

def parse_attribute(attr_list):
    
    parsed_attr_list = []

    for a in attr_list:
        if a.word.lower() == 'tet':
            parsed_attr_list.append('TET')
        elif a.word.lower() == 'tpt':
            parsed_attr_list.append('TPT')
        elif a.word.lower() == 'tndt':
            parsed_attr_list.append('TNDT')
        elif a.word.lower() == 'tst':
            parsed_attr_list.append('TST')
        elif a.word.lower() == 'tudt':
            parsed_attr_list.append('TUDT')
        elif a.word.lower() == 'assists':
            parsed_attr_list.append('assists')
        elif a.word.lower() == 'failures':
            parsed_attr_list.append('failures')
        elif a.word.lower() == 'oee':
            parsed_attr_list.append('OEE')
        elif a.word.lower() == 'mtba':
            parsed_attr_list.append('MTBA')
        elif a.word.lower() == 'mtbf':
            parsed_attr_list.append('MTBF')
        elif a.word.lower() == 'mfe':
            parsed_attr_list.append('MFE')
        elif a.word.lower() == 'uph':
            parsed_attr_list.append('UPH')

    return parsed_attr_list
    
# def parse_machine(machine_list):
#     parsed_machine_list = []

#     for m in machine_list:
#         # machine_exists = machine_dict.check(m.word)
#         parsed_machine_list.append(m.word)
#         if not machine_exists:
#             #get suggestions for the input word
#             suggestions = machine_dict.suggest(m.word)
#             parsed_machine_list.append(suggestions[0])

#     return parsed_machine_list
            

def get_stats(driver, queryObj):
    # separate entities into lists for parsing
    machine_list = [x for x in queryObj.tokens if x.label_ == '<MACHINE>']
    attr_list = [x for x in queryObj.tokens if x.label_ == '<ATTR>']
    temporal_list = [x for x in queryObj.tokens if x.label_ == '<TEMP>']
    time_list = [x for x in temporal_list if is_time(x)]
    date_list = [x for x in temporal_list if is_date(x)]

    #  get full df
    full_query = \
        'MATCH (p:Process {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + "" + \
        '})-[r:RUNS]->(e:Equipment)'  + \
        'return p'

    full_nodes = driver.query(full_query)

    if len(full_nodes) > 0:
        prop_list = list(full_nodes[0]['p'].keys())

        query_string = \
        'MATCH (p:Process {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + '})-[r:RUNS]->(e:Equipment) ' \

        RETURN_CLAUSE = 'RETURN '

        for a in range(len(prop_list)):
                if a != len(prop_list)-1:
                    RETURN_CLAUSE += 'p.' + prop_list[a] + ", "
                else:
                    RETURN_CLAUSE += 'p.' + prop_list[a]
        query_string += RETURN_CLAUSE

        fullDF = pd.DataFrame([dict(_) for _ in driver.query(query_string)])

    else: # return empty results obj
        return 

    parsed_attributes = parse_attribute(attr_list)
    resultsDF = pd.DataFrame()

    for a in parsed_attributes:
        col_name = 'p.' + a

        # if col_name == 'p.OEE':
        #     resultsDF[col_name] = fullDF[]
        #     continue
        if col_name == 'p.UPH':
            resultsDF[col_name] = fullDF['p.goodOutput']/fullDF['p.TPT']
            continue
        if col_name == 'p.MFE':
            resultsDF[col_name] = fullDF['p.TPT'] /(fullDF['p.TPT'] + fullDF['p.TST'] + fullDF['p.TET'] + fullDF['p.TNDT'] + fullDF['p.TUDT'] + fullDF['p.TSDT'])
            continue
        if col_name == 'p.MTBA':
            resultsDF[col_name] = fullDF['p.TPT']/fullDF['p.assists']
            continue
        if col_name == 'p.MTBF':
            resultsDF[col_name] = fullDF['p.TPT']/fullDF['p.failures']
            continue

        resultsDF[col_name] = fullDF[col_name]

    return ResultsObject('stats', resultsDF)