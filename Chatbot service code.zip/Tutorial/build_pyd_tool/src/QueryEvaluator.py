import neo4j
from neo4j import GraphDatabase
import enchant
import pandas as pd


class ResultsObject:

    def __init__(self, type, result):
        self.type = type
        self.result = result

# This method helps to generate a dataframe for a database object
# The row is the object and the columns are the properties of the object
# Arguments:
#   driver - database driver
#   property_query - query to get the properies of the object
#   match_query - query to get the object
# Returns:
#   a dataframe
def parse_dataframe(driver, property_query, match_query):
    properties = driver.query(property_query)

    if len(properties):
        properties = properties[0].values()[0]

        
        RETURN_CLAUSE = 'RETURN '

        for a in range(len(properties)):
                if a != len(properties)-1:
                    RETURN_CLAUSE += 'p.' + properties[a] + ' AS ' + properties[a] + ', '
                else:
                    RETURN_CLAUSE += 'p.' + properties[a] + ' AS ' + properties[a]
        match_query += RETURN_CLAUSE

        return pd.DataFrame([dict(_) for _ in driver.query(match_query)])
        # this dataframe has rows as a process and columns as process properties

    else:
        return

# ========================Get Stats =================================
            
def get_stats(driver, queryObj):
    # get entities
    machine_list = [x for x in queryObj.tokens if x.label_ == '<MACHINE>']
    attr_list = [x for x in queryObj.tokens if x.label_ == '<ATTR>']
    # temporal_list = [x for x in queryObj.tokens if x.label_ == '<TEMP>']
    time_list = [x for x in queryObj.tokens if x.label_ == '<TIME>']
    date_list = [x for x in queryObj.tokens if x.label_ == '<DATE>']


    # get properties (column headers) of obj
    property_query = 'MATCH (p:Process) RETURN keys(p) LIMIT 1'
    match_query = 'MATCH (p:Process {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + '})-[r:RUNS]->(e:Equipment) '

    fullDF = parse_dataframe(driver, property_query, match_query)
    
    resultsDF = pd.DataFrame() # Dataframe to be returned to C#

    for a in attr_list:
        col_name = a.word

        if col_name == 'UPH':
            resultsDF[col_name] = fullDF['goodOutput']/fullDF['TPT']
            continue
        if col_name == 'MFE':
            resultsDF[col_name] = fullDF['TPT'] /(fullDF['TPT'] + fullDF['TST'] + fullDF['TET'] + fullDF['TNDT'] + fullDF['TUDT'] + fullDF['TSDT'])
            continue
        if col_name == 'MTBA':
            resultsDF[col_name] = fullDF['TPT']/fullDF['assists']
            continue
        if col_name == 'MTBF':
            resultsDF[col_name] = fullDF['TPT']/fullDF['failures']
            continue

        resultsDF[col_name] = fullDF[col_name]

    # resultsDF['date'] = date_list[0].word
    # resultsDF['time'] = time_list[0].word
    resultsDF['process ID'] = fullDF['processID']
    resultsDF['EquipmentModel'] = fullDF['equipmentID']

    return ResultsObject('stats', resultsDF)


# ========================= end of get stats ======================================

# ========================= Select General ===============================================
# what are the AB380 with more than 30 TST

def select_general(driver, queryObj):
    machine_list = [x for x in queryObj.tokens if x.label_ == '<MACHINE>']
    attr_list = [x for x in queryObj.tokens if x.label_ == '<ATTR>']
    temporal_list = [x for x in queryObj.tokens if x.label_ == '<TEMP>']
    desc_list = [x for x in queryObj.tokens if x.label_ == '<DESC>']
    quantity_list = [x for x in queryObj.tokens if x.label_ == '<QUANTITY>'] 
    direction_list = [x for x in queryObj.tokens if x.label_ == '<DIRECTION>']
    measurement_list = [x for x in queryObj.tokens if x.label_ == '<MEASUREMENT>']
    # time_list = [x for x in temporal_list if is_time(x)]
    # date_list = [x for x in temporal_list if is_date(x)]

    property_query = 'MATCH (p:Process) RETURN keys(p) LIMIT 1'
    match_query = \
        'MATCH (p:Process {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + "" + \
        '})-[r:RUNS]->(e:Equipment)'
        # 'WHERE p.' + attr_list[0].word + ' ' + desc_list[0].word + ' ' + str(measurement_list[0].word) + ' '
  
    fullDF = parse_dataframe(driver, property_query,match_query)
    # print(fullDF)
    resultsDF = pd.DataFrame()
    intermediateDF = pd.DataFrame()

    for a in attr_list:
        col_name = a.word

        if col_name == 'UPH':
            fullDF[col_name] = fullDF['goodOutput']/fullDF['TPT']
            continue
        if col_name == 'MFE':
            fullDF[col_name] = fullDF['TPT'] /(fullDF['TPT'] + fullDF['TST'] + fullDF['TET'] + fullDF['TNDT'] + fullDF['TUDT'] + fullDF['TSDT'])
            continue
        if col_name == 'MTBA':
            fullDF[col_name] = fullDF['TPT']/fullDF['assists']
            continue
        if col_name == 'MTBF':
            fullDF[col_name] = fullDF['TPT']/fullDF['failures']
            continue

        # resultsDF[col_name] = fullDF[col_name]

    for a in attr_list:
        col_name = a.word
        if desc_list[0].word == '>':
            intermediateDF = fullDF.loc[(fullDF[col_name] > int(measurement_list[0].word))]
            resultsDF[col_name] = intermediateDF[col_name]
        else:
            intermediateDF = fullDF.loc[(fullDF[col_name] < int(measurement_list[0].word))]
            resultsDF[col_name] = intermediateDF[col_name]



    print(resultsDF)
    resultsDF['EquipmentModel'] = fullDF['equipmentID']
    # resultsDF[attr_list[0].word] = fullDF[attr_list[0].word]
    
    

    return ResultsObject('select', resultsDF)

def select_specific(driver, queryObj):
    machine_list = [x for x in queryObj.tokens if x.label_ == '<MACHINE>']
    attr_list = [x for x in queryObj.tokens if x.label_ == '<ATTR>']
    temporal_list = [x for x in queryObj.tokens if x.label_ == '<TEMP>']
    desc_list = [x for x in queryObj.tokens if x.label_ == '<DESC>']
    quantity_list = [x for x in queryObj.tokens if x.label_ == '<QUANTITY>'] 
    direction_list = [x for x in queryObj.tokens if x.label_ == '<DIRECTION>']
    measurement_list = [x for x in queryObj.tokens if x.label_ == '<MEASUREMENT>']
    # time_list = [x for x in temporal_list if is_time(x)]
    # date_list = [x for x in temporal_list if is_date(x)]

    property_query = 'MATCH (p:Process) RETURN keys(p) LIMIT 1'
    match_query = \
        'MATCH (p:Process {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + "" + \
        '})-[r:RUNS]->(e:Equipment)'
        # 'WHERE p.' + attr_list[0].word + ' ' + desc_list[0].word + ' ' + str(measurement_list[0].word) + ' '
  
    fullDF = parse_dataframe(driver, property_query,match_query)
    resultsDF = pd.DataFrame()
    intermediateDF = pd.DataFrame()
    # print(fullDF)
    for a in attr_list:
        col_name = a.word

        if col_name == 'UPH':
            fullDF[col_name] = fullDF['goodOutput']/fullDF['TPT']
            continue
        if col_name == 'MFE':
            fullDF[col_name] = fullDF['TPT'] /(fullDF['TPT'] + fullDF['TST'] + fullDF['TET'] + fullDF['TNDT'] + fullDF['TUDT'] + fullDF['TSDT'])
            continue
        if col_name == 'MTBA':
            fullDF[col_name] = fullDF['TPT']/fullDF['assists']
            continue
        if col_name == 'MTBF':
            fullDF[col_name] = fullDF['TPT']/fullDF['failures']
            continue

        # resultsDF[col_name] = fullDF[col_name]

    for a in attr_list:
        col_name = a.word
        if desc_list[0].word == '>':
            intermediateDF = fullDF.loc[(fullDF[col_name] > int(measurement_list[0].word))]
            intermediateDF.sort_values(by = [col_name], ascending = False, inplace = True)
            resultsDF[col_name] = intermediateDF[col_name].head(int(quantity_list[0].word))
        else:
            intermediateDF = fullDF.loc[(fullDF[col_name] < int(measurement_list[0].word))]
            intermediateDF.sort_values(by = [col_name], ascending = True, inplace = True)
            resultsDF[col_name] = intermediateDF[col_name].head(int(quantity_list[0].word))

    # print(resultsDF)

    resultsDF['EquipmentModel'] = fullDF['equipmentID']
    # resultsDF[attr_list[0].word] = fullDF[attr_list[0].word]
    
    

    return ResultsObject('select', resultsDF)

# ========================= Basic Information ============================================
def basic_info(driver, queryObj):
    machine_list = [x for x in queryObj.tokens if x.label_ == '<MACHINE>']
    # attr_list = [x for x in queryObj.tokens if x.label_ == '<ATTR>']

    match_query = \
        'MATCH (e:Equipment {equipmentModel: '+ '"{}"'.format(machine_list[0].word) + "})" + \
            'RETURN e.description as Description'
        
  
    fullDF = pd.DataFrame([dict(_) for _ in driver.query(match_query)])
    description = fullDF.iloc[0][0]
    # print(description)
    return ResultsObject('basic info', description)


# calls relevant methods for information extraction
def get_results(driver, queryObj):

    if queryObj.intent == 'Basic Information':
        resultObj = basic_info(driver, queryObj)
        return resultObj
    elif queryObj.intent == 'Stats':
        resultObj = get_stats(driver, queryObj)
        return resultObj
    elif queryObj.intent == 'Stats Comparison':
        # resultObj = get_stats_comparison(driver, queryObj)
        print('')
    elif queryObj.intent == 'Stats Specific Comparison':
        print('')
    elif queryObj.intent == 'Reason':
        print('')
    elif queryObj.intent == 'General Selection':
        resultObj = select_general(driver, queryObj)
        return resultObj
    elif queryObj.intent == 'Specific Selection':
        resultObj = select_specific(driver, queryObj)
        return resultObj
    elif queryObj.intent == 'Unknown_Intent':
        print('')



# TODO: Add remaining intent actions
# TODO: Documentation
# TODO: Tidy source code
# TODO: Add validation
# TODO: Tutorial
# TODO: Prepare for full demo

