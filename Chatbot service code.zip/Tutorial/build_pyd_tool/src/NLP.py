import pandas as pd
import spacy
import numpy as np
import sys
import json
import re
import nltk
import pickle
from nltk import word_tokenize, sent_tokenize
from sys import path



padding_tokenizer = spacy.load(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\TOKENIZER_NER_ATTR_OBJ_TEMP_DESC_DIR_MEASUREMENT_QUANTITY')
entity_tokenizer = spacy.load(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\TOKENIZER_NER_ATTR_MACHINE_DATE_TIME_DESC_DIR_MEASUREMENT_QUANTITY')
general_unigram = pickle.load(open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\unigrams.pkl','rb'))
general_bigram = pickle.load(open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\bigrams.pkl','rb'))
general_unibigram = pickle.load(open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\unibigrams.pkl', 'rb'))

stats_unigram = pickle.load(open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\stats_unigrams.pkl', 'rb'))
# stats_bigram = pickle.load(open('stats_bigrams.pkl', 'rb'))

select_unigram = pickle.load(open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\select_unigrams.pkl', 'rb'))
# select_bigram = pickle.load(open('select_bigrams.pkl', 'rb'))

# # General intent classifier
with open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\model1gram.pkl', 'rb') as f:
    model_uni = pickle.load(f)
# General intent classifier
with open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\model2gram.pkl', 'rb') as f:
    model_bi = pickle.load(f)
# General intent classifier
with open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\model12gram.pkl', 'rb') as f:
    model_uni_bi = pickle.load(f)

# Stats intent classifier
with open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\stats_model1gram.pkl', 'rb') as f:
    stats_model_uni = pickle.load(f)
# # Select intent classifier
with open(r'C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\select_model1gram.pkl', 'rb') as f:
    select_model_uni = pickle.load(f)

# Contains information about a word token
# Information includes the entity type for the word
class Token:
    def __init__(self, word, entity_label_):
        self.word = word # string
        self.label_ = entity_label_ # string
    
    def info(self):
        return self.word + " | " + self.label_

# Contains information about a query
# list of tokens
# list of invalid tokens
# the intent of the query
# the original query
class QueryObject:
    # query - original sentence
    # tokens - list of tokens
    # intent - intent
    # invalid = list of invalid tokens
    def __init__(self, intent, query, tokens, invalid = []):
        self.query = query # string
        self.tokens = tokens # list of Token objects
        self.intent = intent # string
        self.invalid_entities = invalid # list of Token objects

    # prints detail about - Intent,  list of valid entities, list of invalid entities
    def info(self):
        print("INTENT:")
        print("\t" + self.intent)
        print("ENTITIES:")
        for t in self.tokens:
            print("\t" + t.info())
        print("INVALID")
        if len(self.invalid_entities) != 0:
            for i in self.invalid_entities:
                print("\t" + i.word + " | " +  i.label_)

    # returns details about - Intent, list of valid entities, list of invalid entities
    # return type is a string
    def details(self):
        deets = ""
        deets += "INTENT: \n"
        deets += "\t" + self.intent + "\n"
        deets += "ENTITIES:\n"
        for t in self.tokens:
            deets += "\t" + t.info() + "\n"
        deets += "INVALID:\n"
        if len(self.invalid_entities) != 0:
            for i in self.invalid_entities:
                deets += "\t" + i.word + " | " +  i.label_ + "\n"
                
        return deets

# Vectorizes query into BoW format
# Prepare to predict the query
def vectorise_query(query, vocab_list):
    query = re.sub(r'[^\w]', ' ', query).lower()

    query_tokens = nltk.word_tokenize(query)
    BoW = []
    # onegram = pd.DataFrame()
    for t in vocab_list:
        if t in query_tokens:
            BoW.append(1)
        else:
            BoW.append(0)

    # print(len(BoW))
    return BoW

# returns a list of Token objects from the original query. 
# Each token object is a word and the corresponding entity type
# Entities are padded entities - <OBJ>, <DIR>, <DESC>, <ATTR>, <TEMPORAL>
# This is done to normalize the query by reducing unncessary variations in sentences
def tokenize(query, tokenizer):
    doc = tokenizer(query) # calls the model to extract the entities 
    res = []

    entity_positions = [(e.start, e.end) for e in doc.ents] # gets the positions of each entity
    d = 0
    while d < len(doc):
        if(len(entity_positions) != 0):
            start = entity_positions[0][0]
            end = entity_positions[0][1]
    
        if(doc[d].ent_type_ == ''): # if token has no entity
            res.append(Token(doc[d].text, doc[d].ent_type_))
            d = d+1
        else: # if token has entity
            word = ''
            e = start
            while e < end:
                word+= doc[e].text + ' '
                # d+=1
                e+=1 
            res.append(Token(word.strip(), doc[d].ent_type_))
            d = e
            del entity_positions[0]

    return res

# gets intent from the token list
# currently uses unigram model
# the code for bigram and uni+bigram model is are commented out
def classify(tokens):
    # preprocess query
    query_padded = ""
    for t in tokens:
        if t.label_ == "":
            query_padded += t.word + " "
        else:
            query_padded += t.label_ + " "
    query_padded = query_padded.strip()

    query_original = ""
    for t in tokens:
        query_original += t.word + " "
    query_original = query_original.strip()

    # 0 - Get stats
    # 1 - Reason
    # 2 - Select
    # call intent classifier
    

# ========================= uni gram =======================================

    bag_of_unigram = vectorise_query(query_padded, general_unigram) # BoW array
    intent_uni = model_uni.predict([bag_of_unigram]) # general intent classification
    if intent_uni == 0:
        # intent_uni = 'Get Statistics'
        bo_stats_uni = vectorise_query(query_padded, stats_unigram)
        intent_uni = stats_model_uni.predict([bo_stats_uni])

        if intent_uni == 0:
            intent_uni = 'Basic Information'
        elif intent_uni == 1:
            intent_uni = 'Stats'
        elif intent_uni == 2:
            intent_uni = 'Stats Comparison'
        elif intent_uni == 3:
            intent_uni = 'Stats Specific Comparison'

    elif intent_uni == 1:
        intent_uni = 'Reason'
    elif intent_uni == 2:
        # intent_uni = 'Select'
        bo_select_uni = vectorise_query(query_padded, select_unigram)
        intent_uni = select_model_uni.predict([bo_select_uni])

        if intent_uni == 0:
            intent_uni = 'General Selection'
        elif intent_uni == 1:
            intent_uni = 'Specific Selection'

#  =========================== bi gram ===================================
   
    # bo_bigram = vectorise_query(query_padded, general_bigram) # BoW array
    # intent_bi = model_uni.predict([bo_bigram]) # general intent classification

    
    # if intent_bi == 0:
    #     # intent_uni = 'Get Statistics'
    #     bo_stats_bi = vectorise_query(query_padded, stats_unigram)
    #     intent_bi = stats_model_uni.predict([bo_stats_bi])

    #     if intent_bi == 0:
    #         intent_bi = 'Basic Information'
    #     elif intent_bi == 1:
    #         intent_bi = 'Get Comparison'
    #     elif intent_bi == 2:
    #         intent_bi = 'Get Statistics'

    # elif intent_bi == 1:
    #     intent_bi = 'Reason'
    # elif intent_bi == 2:
    #     # intent_uni = 'Select'
    #     bo_select_bi = vectorise_query(query_padded, select_unigram)
    #     intent_bi = select_model_uni.predict([bo_select_bi])

    #     if intent_bi == 0:
    #         intent_bi = 'General Selection'
    #     elif intent_bi == 1:
    #         intent_bi = 'Specific Selection'



    # create and return query object
    # query_obj = QueryObject(intent_uni, query_original, tokens)
    # return query_obj

#  =========================== unibi gram ===================================
   
    # bo_unibigram = vectorise_query(query_padded, general_unibigram) # BoW array
    # intent_unibi = model_uni_bi.predict([bo_unibigram]) # general intent classification

    
    # if intent_unibi == 0:
    #     # intent_uni = 'Get Statistics'
    #     bo_stats_uni = vectorise_query(query_padded, stats_unigram)
    #     intent_unibi = stats_model_uni.predict([bo_stats_uni])

    #     if intent_unibi == 0:
    #         intent_unibi = 'Basic Information'
    #     elif intent_unibi == 1:
    #         intent_bi = 'Get Comparison'
    #     elif intent_unibi == 2:
    #         intent_unibi = 'Get Statistics'

    # elif intent_unibi == 1:
    #     intent_unibi = 'Reason'
    # elif intent_unibi == 2:
    #     # intent_uni = 'Select'
    #     bo_select_bi = vectorise_query(query_padded, select_unigram)
    #     intent_unibi = select_model_uni.predict([bo_select_bi])

    #     if intent_unibi == 0:
    #         intent_unibi = 'General Selection'
    #     elif intent_unibi == 1:
    #         intent_unibi = 'Specific Selection'



    # create and return query object
    query_obj = QueryObject(intent_uni, query_original, tokens)
    return query_obj

# C# will call this method
def process_query(query):
    list_of_tokens = tokenize(query, padding_tokenizer) # preprocesses query - pads them with tokens
    query_obj = classify(list_of_tokens) # get intent
    return query_obj # query object

#  tokenize -> classify -> extract entities -> return QueryObject (intent + entities) to C#



