import json

# get machine json
with open(r"C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\Machine.json", encoding="utf8") as f:
    machine_list = json.loads(f.read()) # json list
    machines = [m for m in machine_list['Machine Names']] # convert to python list

# get attribute json
with open(r"C:\Users\Luk Chi Heng\AppData\Local\Programs\Python\Python37\Lib\site-packages\Attribute2.json", encoding="utf8") as f:
    attribute_list = json.loads(f.read()) # python dict

class Parsed_Entities:
    def __init__(self, valid, invalid):
        self.valid = valid
        self.invalid = invalid

class Token:
    def __init__(self, word, entity_label_):
        self.word = word # string
        self.label_ = entity_label_ # string
    
    def info(self):
        return self.word + " | " + self.label_

# Argument: list of machine tokens from user's query
# Returns: Parsed_Entities object
def parse_machine(list_of_machine):
    valid = []
    invalid = []

    for given_mach in list_of_machine:
        is_valid = False
        for m in machines:
            if given_mach.word.lower() == m.lower():
                valid.append(Token(m, '<MACHINE>'))
                is_valid = True
                break
        if not is_valid:
            invalid.append(given_mach)


    return Parsed_Entities(valid, invalid)

# Argument: list of attribute tokens from user's query
# Returns: Parsed_Entities object
def parse_attribute(list_of_attr):
    valid = []
    invalid =  []

    for given_attr in list_of_attr:
        is_valid = False
        for real_attr in attribute_list:
            attr_abrev = real_attr
            attr_full = attribute_list[real_attr]

            if given_attr.word.lower() == attr_abrev.lower() or given_attr.word.lower() == attr_full.lower():
                valid.append(Token(attr_abrev, "<ATTR>"))
                is_valid = True
                break
        if not is_valid:
            invalid.append(given_attr)

    return Parsed_Entities(valid, invalid)

# 
def is_date(temporal):
    date_words = ['jan', 'january', 'feb', 'feburary', 'mar', 'march', 'apr', 'april',
    'may', 'jun', 'june', 'jul', 'july', 'aug', 'august', 'sep', 'september', 'oct', 'october',
    'nov', 'november', 'dec', 'december', 'day', 'days', 'mon', 'monday', 'tues', 'tuesday', 'wed',
    'wednesday', 'thurs', 'thursday', 'fri', 'friday', 'sat', 'saturday', 'sun', 'sunday', 'week',
    'day', 'month', 'year']

    for d in date_words:
        if temporal.contains(d):
            return True
    
    return False

def is_time(temporal):
    time_words = ['hr', 'hour', 'min', 'minute']

    for t in time_words:
        if temporal.contains(t):
            return True
    
    return False

# 
def parse_date(list_of_date):
    return ""

def parse_time(list_of_time):
    return ""
# 
def parse_direction(list_of_direction):
    return ""
# Argument: list of description tokens from user
# Returns: >, <
def parse_description(list_of_desc):
    desc = list_of_desc[0].lower()
    list_of_more = ['great', 'high', 'long', 'more', '>']
    list_of_less = ['low', 'less', 'few', 'fall', 'least', '<']

    for m in list_of_more:
        if desc.contains(m):
            return '>'
    for l in list_of_less:
        if desc.contains(l):
            return '<'


def parse_measurement(list_of_measurement):
    return ""
def parse_quantity(list_of_quantity):  
    return ""